When adding a use case

1. create file here
2. add to AppContainer noteUseCases class