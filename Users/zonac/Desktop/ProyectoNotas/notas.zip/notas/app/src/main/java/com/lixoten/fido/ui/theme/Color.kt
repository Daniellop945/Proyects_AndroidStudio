package com.lixoten.fido.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFFC8686)
val Purple500 = Color(0xFFEE0000)
val Purple700 = Color(0xFFB30000)
val Teal200 = Color(0xFF03DAC5)
val RedOrange = Color(0xffffab91)
val RedPink = Color(0xfff48fb1)
val BabyBlue = Color(0xff81deea)
val Violet = Color(0xffcf94da)
val LightGreen = Color(0xffe7ed9b)