package com.lixoten.fido.navigation

interface NavigationDestination {
    val route: String
    val titleRes: Int
}